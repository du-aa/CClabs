﻿namespace CompiladorEasyCaio
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarComoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desfazerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.refazerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.recortarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.colarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.selecionarTudoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.procurarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.substituirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuracoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chkQuebraDeLinhas = new System.Windows.Forms.ToolStripMenuItem();
            this.chkScrollMap = new System.Windows.Forms.ToolStripMenuItem();
            this.esconderErroListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.teclasDeAtalhosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comandosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cboTemas = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.corDeFundoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fonteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.txtOutput = new System.Windows.Forms.ToolStripTextBox();
            this.btnPastaSaidaExe = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnCompilar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.chkDestacarLinhaAtual = new System.Windows.Forms.ToolStripButton();
            this.chkExibirDobrasDeLinhas = new System.Windows.Forms.ToolStripButton();
            this.chkAutoFecharChaves = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.btnComentar = new System.Windows.Forms.ToolStripButton();
            this.btnDescomentar = new System.Windows.Forms.ToolStripButton();
            this.btnAutoIdentar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAddBookMarks = new System.Windows.Forms.ToolStripButton();
            this.btnRemoverBookMarks = new System.Windows.Forms.ToolStripButton();
            this.btnBookBack = new System.Windows.Forms.ToolStripButton();
            this.btnBookNext = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.lblFramworkInfo = new System.Windows.Forms.ToolStripLabel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblQtdCaracteres = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblLinhaAtual = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblColunaAtual = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.documentMap1 = new FastColoredTextBoxNS.DocumentMap();
            this.fctb = new FastColoredTextBoxNS.FastColoredTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.recortarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selecionarTudoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.desfazerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refazerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.procurarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.substituirToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.clonarLinhaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clonarComComentarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.destacarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.azulToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vermelhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.amareloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verdeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.removerDestaqueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linkPastaArquivos = new System.Windows.Forms.LinkLabel();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fctb)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.editarToolStripMenuItem,
            this.configuracoesToolStripMenuItem,
            this.ajudaToolStripMenuItem,
            this.cboTemas,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(627, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novoToolStripMenuItem,
            this.abrirToolStripMenuItem,
            this.salvarToolStripMenuItem,
            this.salvarComoToolStripMenuItem,
            this.toolStripSeparator3,
            this.imprimirToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(61, 23);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // novoToolStripMenuItem
            // 
            this.novoToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.newfile;
            this.novoToolStripMenuItem.Name = "novoToolStripMenuItem";
            this.novoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.novoToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.novoToolStripMenuItem.Text = "Novo";
            this.novoToolStripMenuItem.Click += new System.EventHandler(this.novoToolStripMenuItem_Click);
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.openfile;
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.abrirToolStripMenuItem.Text = "Abrir";
            this.abrirToolStripMenuItem.Click += new System.EventHandler(this.abrirToolStripMenuItem_Click);
            // 
            // salvarToolStripMenuItem
            // 
            this.salvarToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.save;
            this.salvarToolStripMenuItem.Name = "salvarToolStripMenuItem";
            this.salvarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.salvarToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.salvarToolStripMenuItem.Text = "Salvar";
            this.salvarToolStripMenuItem.Click += new System.EventHandler(this.salvarToolStripMenuItem_Click);
            // 
            // salvarComoToolStripMenuItem
            // 
            this.salvarComoToolStripMenuItem.Name = "salvarComoToolStripMenuItem";
            this.salvarComoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt) 
            | System.Windows.Forms.Keys.S)));
            this.salvarComoToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.salvarComoToolStripMenuItem.Text = "Salvar Como";
            this.salvarComoToolStripMenuItem.Click += new System.EventHandler(this.salvarComoToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(201, 6);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.printer;
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            this.imprimirToolStripMenuItem.Click += new System.EventHandler(this.imprimirToolStripMenuItem_Click);
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.desfazerToolStripMenuItem1,
            this.refazerToolStripMenuItem1,
            this.toolStripSeparator10,
            this.recortarToolStripMenuItem1,
            this.copiarToolStripMenuItem1,
            this.colarToolStripMenuItem1,
            this.selecionarTudoToolStripMenuItem1,
            this.toolStripSeparator11,
            this.procurarToolStripMenuItem,
            this.substituirToolStripMenuItem});
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(49, 23);
            this.editarToolStripMenuItem.Text = "Editar";
            // 
            // desfazerToolStripMenuItem1
            // 
            this.desfazerToolStripMenuItem1.Image = global::CompiladorEasyCaio.Properties.Resources.backarrow;
            this.desfazerToolStripMenuItem1.Name = "desfazerToolStripMenuItem1";
            this.desfazerToolStripMenuItem1.ShortcutKeyDisplayString = "Ctrl+Z";
            this.desfazerToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.desfazerToolStripMenuItem1.Text = "Desfazer";
            this.desfazerToolStripMenuItem1.Click += new System.EventHandler(this.desfazerToolStripMenuItem1_Click);
            // 
            // refazerToolStripMenuItem1
            // 
            this.refazerToolStripMenuItem1.Image = global::CompiladorEasyCaio.Properties.Resources.nextarrow;
            this.refazerToolStripMenuItem1.Name = "refazerToolStripMenuItem1";
            this.refazerToolStripMenuItem1.ShortcutKeyDisplayString = "Ctrl+Y";
            this.refazerToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.refazerToolStripMenuItem1.Text = "Refazer";
            this.refazerToolStripMenuItem1.Click += new System.EventHandler(this.refazerToolStripMenuItem1_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(156, 6);
            // 
            // recortarToolStripMenuItem1
            // 
            this.recortarToolStripMenuItem1.Image = global::CompiladorEasyCaio.Properties.Resources.cutpng;
            this.recortarToolStripMenuItem1.Name = "recortarToolStripMenuItem1";
            this.recortarToolStripMenuItem1.ShortcutKeyDisplayString = "Ctrl+X";
            this.recortarToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.recortarToolStripMenuItem1.Text = "Recortar";
            this.recortarToolStripMenuItem1.Click += new System.EventHandler(this.recortarToolStripMenuItem1_Click);
            // 
            // copiarToolStripMenuItem1
            // 
            this.copiarToolStripMenuItem1.Image = global::CompiladorEasyCaio.Properties.Resources.copypng;
            this.copiarToolStripMenuItem1.Name = "copiarToolStripMenuItem1";
            this.copiarToolStripMenuItem1.ShortcutKeyDisplayString = "Ctrl+C";
            this.copiarToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.copiarToolStripMenuItem1.Text = "Copiar";
            this.copiarToolStripMenuItem1.Click += new System.EventHandler(this.copiarToolStripMenuItem1_Click);
            // 
            // colarToolStripMenuItem1
            // 
            this.colarToolStripMenuItem1.Image = global::CompiladorEasyCaio.Properties.Resources.pastepng;
            this.colarToolStripMenuItem1.Name = "colarToolStripMenuItem1";
            this.colarToolStripMenuItem1.ShortcutKeyDisplayString = "Ctrl+V";
            this.colarToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.colarToolStripMenuItem1.Text = "Colar";
            this.colarToolStripMenuItem1.Click += new System.EventHandler(this.colarToolStripMenuItem1_Click);
            // 
            // selecionarTudoToolStripMenuItem1
            // 
            this.selecionarTudoToolStripMenuItem1.Name = "selecionarTudoToolStripMenuItem1";
            this.selecionarTudoToolStripMenuItem1.Size = new System.Drawing.Size(159, 22);
            this.selecionarTudoToolStripMenuItem1.Text = "Selecionar Tudo";
            this.selecionarTudoToolStripMenuItem1.Click += new System.EventHandler(this.selecionarTudoToolStripMenuItem1_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(156, 6);
            // 
            // procurarToolStripMenuItem
            // 
            this.procurarToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.search;
            this.procurarToolStripMenuItem.Name = "procurarToolStripMenuItem";
            this.procurarToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+F";
            this.procurarToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.procurarToolStripMenuItem.Tag = "procurar";
            this.procurarToolStripMenuItem.Text = "Procurar";
            this.procurarToolStripMenuItem.Click += new System.EventHandler(this.procurarToolStripMenuItem_Click);
            // 
            // substituirToolStripMenuItem
            // 
            this.substituirToolStripMenuItem.Name = "substituirToolStripMenuItem";
            this.substituirToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.substituirToolStripMenuItem.Tag = "substituir";
            this.substituirToolStripMenuItem.Text = "Substituir";
            this.substituirToolStripMenuItem.Click += new System.EventHandler(this.substituirToolStripMenuItem_Click);
            // 
            // configuracoesToolStripMenuItem
            // 
            this.configuracoesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chkQuebraDeLinhas,
            this.chkScrollMap,
            this.esconderErroListToolStripMenuItem,
            this.toolStripSeparator12,
            this.teclasDeAtalhosToolStripMenuItem});
            this.configuracoesToolStripMenuItem.Name = "configuracoesToolStripMenuItem";
            this.configuracoesToolStripMenuItem.Size = new System.Drawing.Size(96, 23);
            this.configuracoesToolStripMenuItem.Text = "Configurações";
            // 
            // chkQuebraDeLinhas
            // 
            this.chkQuebraDeLinhas.CheckOnClick = true;
            this.chkQuebraDeLinhas.Name = "chkQuebraDeLinhas";
            this.chkQuebraDeLinhas.Size = new System.Drawing.Size(183, 22);
            this.chkQuebraDeLinhas.Text = "Quebra de Linhas";
            this.chkQuebraDeLinhas.CheckedChanged += new System.EventHandler(this.quebraDeLinhasToolStripMenuItem_CheckedChanged);
            // 
            // chkScrollMap
            // 
            this.chkScrollMap.CheckOnClick = true;
            this.chkScrollMap.Name = "chkScrollMap";
            this.chkScrollMap.Size = new System.Drawing.Size(183, 22);
            this.chkScrollMap.Text = "Scroll Map";
            this.chkScrollMap.CheckedChanged += new System.EventHandler(this.scrollMapPersonalizadoToolStripMenuItem_CheckedChanged);
            // 
            // esconderErroListToolStripMenuItem
            // 
            this.esconderErroListToolStripMenuItem.CheckOnClick = true;
            this.esconderErroListToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.hide;
            this.esconderErroListToolStripMenuItem.Name = "esconderErroListToolStripMenuItem";
            this.esconderErroListToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.esconderErroListToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.esconderErroListToolStripMenuItem.Text = "Esconder ErroList";
            this.esconderErroListToolStripMenuItem.CheckedChanged += new System.EventHandler(this.esconderErroListToolStripMenuItem_CheckedChanged);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(180, 6);
            // 
            // teclasDeAtalhosToolStripMenuItem
            // 
            this.teclasDeAtalhosToolStripMenuItem.Name = "teclasDeAtalhosToolStripMenuItem";
            this.teclasDeAtalhosToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.teclasDeAtalhosToolStripMenuItem.Text = "Teclas de Atalhos";
            this.teclasDeAtalhosToolStripMenuItem.Click += new System.EventHandler(this.teclasDeAtalhosToolStripMenuItem_Click);
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comandosToolStripMenuItem,
            this.sobreToolStripMenuItem});
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(50, 23);
            this.ajudaToolStripMenuItem.Text = "Ajuda";
            // 
            // comandosToolStripMenuItem
            // 
            this.comandosToolStripMenuItem.Name = "comandosToolStripMenuItem";
            this.comandosToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.comandosToolStripMenuItem.Text = "Comandos";
            this.comandosToolStripMenuItem.Click += new System.EventHandler(this.comandosToolStripMenuItem_Click);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.sobreToolStripMenuItem.Text = "Sobre";
            this.sobreToolStripMenuItem.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // cboTemas
            // 
            this.cboTemas.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.cboTemas.BackColor = System.Drawing.SystemColors.MenuBar;
            this.cboTemas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTemas.Items.AddRange(new object[] {
            "Light",
            "Dark",
            "Brown",
            "PinkW"});
            this.cboTemas.Name = "cboTemas";
            this.cboTemas.Size = new System.Drawing.Size(81, 23);
            this.cboTemas.SelectedIndexChanged += new System.EventHandler(this.cboTemas_SelectedIndexChanged);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.corDeFundoToolStripMenuItem,
            this.fonteToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(54, 23);
            this.toolStripMenuItem1.Text = "Mudar";
            // 
            // corDeFundoToolStripMenuItem
            // 
            this.corDeFundoToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.backgroundcolor;
            this.corDeFundoToolStripMenuItem.Name = "corDeFundoToolStripMenuItem";
            this.corDeFundoToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.corDeFundoToolStripMenuItem.Text = "Cor de Fundo";
            this.corDeFundoToolStripMenuItem.Click += new System.EventHandler(this.corDeFundoToolStripMenuItem_Click);
            // 
            // fonteToolStripMenuItem
            // 
            this.fonteToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.font;
            this.fonteToolStripMenuItem.Name = "fonteToolStripMenuItem";
            this.fonteToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.fonteToolStripMenuItem.Text = "Fonte";
            this.fonteToolStripMenuItem.Click += new System.EventHandler(this.fonteToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.txtOutput,
            this.btnPastaSaidaExe,
            this.toolStripSeparator1,
            this.btnCompilar,
            this.toolStripSeparator2,
            this.chkDestacarLinhaAtual,
            this.chkExibirDobrasDeLinhas,
            this.chkAutoFecharChaves,
            this.toolStripSeparator4,
            this.btnComentar,
            this.btnDescomentar,
            this.btnAutoIdentar,
            this.toolStripSeparator5,
            this.btnAddBookMarks,
            this.btnRemoverBookMarks,
            this.btnBookBack,
            this.btnBookNext,
            this.toolStripSeparator6,
            this.lblFramworkInfo});
            this.toolStrip1.Location = new System.Drawing.Point(0, 27);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(627, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(58, 22);
            this.toolStripLabel1.Text = "Saida(F2):";
            // 
            // txtOutput
            // 
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(70, 25);
            this.txtOutput.Text = "teste.exe";
            this.txtOutput.Click += new System.EventHandler(this.txtOutput_Click);
            // 
            // btnPastaSaidaExe
            // 
            this.btnPastaSaidaExe.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPastaSaidaExe.Image = global::CompiladorEasyCaio.Properties.Resources.folder;
            this.btnPastaSaidaExe.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPastaSaidaExe.Name = "btnPastaSaidaExe";
            this.btnPastaSaidaExe.Size = new System.Drawing.Size(23, 22);
            this.btnPastaSaidaExe.Text = "toolStripButton1";
            this.btnPastaSaidaExe.Click += new System.EventHandler(this.btnPastaSaidaExe_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnCompilar
            // 
            this.btnCompilar.AutoSize = false;
            this.btnCompilar.BackColor = System.Drawing.Color.DarkGreen;
            this.btnCompilar.ForeColor = System.Drawing.Color.LightGreen;
            this.btnCompilar.Image = global::CompiladorEasyCaio.Properties.Resources.compile;
            this.btnCompilar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCompilar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCompilar.Name = "btnCompilar";
            this.btnCompilar.Size = new System.Drawing.Size(71, 20);
            this.btnCompilar.Text = "Start(F5)";
            this.btnCompilar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCompilar.Click += new System.EventHandler(this.btnCompilar_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Margin = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // chkDestacarLinhaAtual
            // 
            this.chkDestacarLinhaAtual.Checked = true;
            this.chkDestacarLinhaAtual.CheckOnClick = true;
            this.chkDestacarLinhaAtual.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDestacarLinhaAtual.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.chkDestacarLinhaAtual.Image = global::CompiladorEasyCaio.Properties.Resources.selectionline;
            this.chkDestacarLinhaAtual.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.chkDestacarLinhaAtual.Name = "chkDestacarLinhaAtual";
            this.chkDestacarLinhaAtual.Size = new System.Drawing.Size(23, 22);
            this.chkDestacarLinhaAtual.ToolTipText = "Exibe uma cor de fundo na linha atual";
            this.chkDestacarLinhaAtual.CheckedChanged += new System.EventHandler(this.chksToolStrip_CheckedChanged);
            // 
            // chkExibirDobrasDeLinhas
            // 
            this.chkExibirDobrasDeLinhas.Checked = true;
            this.chkExibirDobrasDeLinhas.CheckOnClick = true;
            this.chkExibirDobrasDeLinhas.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkExibirDobrasDeLinhas.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.chkExibirDobrasDeLinhas.Image = global::CompiladorEasyCaio.Properties.Resources.graphic;
            this.chkExibirDobrasDeLinhas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.chkExibirDobrasDeLinhas.Name = "chkExibirDobrasDeLinhas";
            this.chkExibirDobrasDeLinhas.Size = new System.Drawing.Size(23, 22);
            this.chkExibirDobrasDeLinhas.ToolTipText = "Exibir Dobra de Linhas";
            this.chkExibirDobrasDeLinhas.CheckedChanged += new System.EventHandler(this.chksToolStrip_CheckedChanged);
            // 
            // chkAutoFecharChaves
            // 
            this.chkAutoFecharChaves.Checked = true;
            this.chkAutoFecharChaves.CheckOnClick = true;
            this.chkAutoFecharChaves.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAutoFecharChaves.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.chkAutoFecharChaves.Image = global::CompiladorEasyCaio.Properties.Resources.bracketsauto;
            this.chkAutoFecharChaves.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.chkAutoFecharChaves.Name = "chkAutoFecharChaves";
            this.chkAutoFecharChaves.Size = new System.Drawing.Size(23, 22);
            this.chkAutoFecharChaves.ToolTipText = "(AutoCompleteBrackets) fechamento automatico de chaves {}";
            this.chkAutoFecharChaves.CheckedChanged += new System.EventHandler(this.chksToolStrip_CheckedChanged);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // btnComentar
            // 
            this.btnComentar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnComentar.Image = global::CompiladorEasyCaio.Properties.Resources.comment;
            this.btnComentar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnComentar.Name = "btnComentar";
            this.btnComentar.Size = new System.Drawing.Size(23, 22);
            this.btnComentar.Tag = "comentar";
            this.btnComentar.ToolTipText = "Comentar a linha ou seleção";
            this.btnComentar.Click += new System.EventHandler(this.btnComentar_Click);
            // 
            // btnDescomentar
            // 
            this.btnDescomentar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnDescomentar.Image = global::CompiladorEasyCaio.Properties.Resources.uncomment;
            this.btnDescomentar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDescomentar.Name = "btnDescomentar";
            this.btnDescomentar.Size = new System.Drawing.Size(23, 22);
            this.btnDescomentar.Tag = "descomentar";
            this.btnDescomentar.ToolTipText = "Remove o comentario da linha";
            this.btnDescomentar.Click += new System.EventHandler(this.btnComentar_Click);
            // 
            // btnAutoIdentar
            // 
            this.btnAutoIdentar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAutoIdentar.Image = global::CompiladorEasyCaio.Properties.Resources.identity;
            this.btnAutoIdentar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAutoIdentar.Name = "btnAutoIdentar";
            this.btnAutoIdentar.Size = new System.Drawing.Size(23, 22);
            this.btnAutoIdentar.ToolTipText = "(AutoIdent) Aplicará ajuste automatico na seleção";
            this.btnAutoIdentar.Click += new System.EventHandler(this.btnAutoIdentar_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // btnAddBookMarks
            // 
            this.btnAddBookMarks.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAddBookMarks.Image = global::CompiladorEasyCaio.Properties.Resources.bookmarkadd;
            this.btnAddBookMarks.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAddBookMarks.Name = "btnAddBookMarks";
            this.btnAddBookMarks.Size = new System.Drawing.Size(23, 22);
            this.btnAddBookMarks.Tag = "AddBook";
            this.btnAddBookMarks.ToolTipText = "Adicionar BookMark (ctrl+B)";
            this.btnAddBookMarks.Click += new System.EventHandler(this.btnsBookMarks_Click);
            // 
            // btnRemoverBookMarks
            // 
            this.btnRemoverBookMarks.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnRemoverBookMarks.Image = ((System.Drawing.Image)(resources.GetObject("btnRemoverBookMarks.Image")));
            this.btnRemoverBookMarks.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRemoverBookMarks.Name = "btnRemoverBookMarks";
            this.btnRemoverBookMarks.Size = new System.Drawing.Size(23, 22);
            this.btnRemoverBookMarks.Tag = "RemoveBook";
            this.btnRemoverBookMarks.ToolTipText = "Remover BookMark (ctrl+shift+B)";
            this.btnRemoverBookMarks.Click += new System.EventHandler(this.btnsBookMarks_Click);
            // 
            // btnBookBack
            // 
            this.btnBookBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnBookBack.Image = global::CompiladorEasyCaio.Properties.Resources.bookmarkback;
            this.btnBookBack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBookBack.Name = "btnBookBack";
            this.btnBookBack.Size = new System.Drawing.Size(23, 22);
            this.btnBookBack.Tag = "BackBook";
            this.btnBookBack.Text = "toolStripButton3";
            this.btnBookBack.ToolTipText = "Anterior BookMark (ctrl+N) ";
            this.btnBookBack.Click += new System.EventHandler(this.btnsBookMarks_Click);
            // 
            // btnBookNext
            // 
            this.btnBookNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnBookNext.Image = global::CompiladorEasyCaio.Properties.Resources.bookmarknext;
            this.btnBookNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBookNext.Name = "btnBookNext";
            this.btnBookNext.Size = new System.Drawing.Size(23, 22);
            this.btnBookNext.Tag = "NextBook";
            this.btnBookNext.Text = "toolStripButton3";
            this.btnBookNext.ToolTipText = "Proximo BookMark (ctrl+shift+N)";
            this.btnBookNext.Click += new System.EventHandler(this.btnsBookMarks_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // lblFramworkInfo
            // 
            this.lblFramworkInfo.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lblFramworkInfo.Name = "lblFramworkInfo";
            this.lblFramworkInfo.Size = new System.Drawing.Size(84, 22);
            this.lblFramworkInfo.Text = "Framework 4.0";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblQtdCaracteres,
            this.lblLinhaAtual,
            this.lblColunaAtual});
            this.statusStrip1.Location = new System.Drawing.Point(0, 444);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(627, 24);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblQtdCaracteres
            // 
            this.lblQtdCaracteres.Name = "lblQtdCaracteres";
            this.lblQtdCaracteres.Size = new System.Drawing.Size(96, 19);
            this.lblQtdCaracteres.Text = "Caracteres: XXXX";
            // 
            // lblLinhaAtual
            // 
            this.lblLinhaAtual.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.lblLinhaAtual.Margin = new System.Windows.Forms.Padding(50, 3, 0, 2);
            this.lblLinhaAtual.Name = "lblLinhaAtual";
            this.lblLinhaAtual.Size = new System.Drawing.Size(60, 19);
            this.lblLinhaAtual.Text = "Linha: XX";
            // 
            // lblColunaAtual
            // 
            this.lblColunaAtual.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.lblColunaAtual.Margin = new System.Windows.Forms.Padding(20, 3, 0, 2);
            this.lblColunaAtual.Name = "lblColunaAtual";
            this.lblColunaAtual.Size = new System.Drawing.Size(69, 19);
            this.lblColunaAtual.Text = "Coluna: XX";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 52);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.documentMap1);
            this.splitContainer1.Panel1.Controls.Add(this.fctb);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.linkPastaArquivos);
            this.splitContainer1.Panel2.Controls.Add(this.txtStatus);
            this.splitContainer1.Size = new System.Drawing.Size(627, 392);
            this.splitContainer1.SplitterDistance = 327;
            this.splitContainer1.TabIndex = 3;
            // 
            // documentMap1
            // 
            this.documentMap1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.documentMap1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.documentMap1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.documentMap1.ForeColor = System.Drawing.Color.DarkTurquoise;
            this.documentMap1.Location = new System.Drawing.Point(475, 0);
            this.documentMap1.Name = "documentMap1";
            this.documentMap1.ScrollbarVisible = false;
            this.documentMap1.Size = new System.Drawing.Size(152, 327);
            this.documentMap1.TabIndex = 1;
            this.documentMap1.Target = this.fctb;
            this.documentMap1.Text = "documentMap1";
            this.documentMap1.Visible = false;
            // 
            // fctb
            // 
            this.fctb.AllowSeveralTextStyleDrawing = true;
            this.fctb.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fctb.AutoCompleteBrackets = true;
            this.fctb.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.fctb.AutoIndentCharsPatterns = "\r\n^\\s*[\\w\\.]+(\\s\\w+)?\\s*(?<range>=)\\s*(?<range>[^;]+);\r\n^\\s*(case|default)\\s*[^:]" +
    "*(?<range>:)\\s*(?<range>[^;]+);\r\n";
            this.fctb.AutoScrollMinSize = new System.Drawing.Size(40, 15);
            this.fctb.BackBrush = null;
            this.fctb.BookmarkColor = System.Drawing.Color.DarkSlateGray;
            this.fctb.BracketsHighlightStrategy = FastColoredTextBoxNS.BracketsHighlightStrategy.Strategy2;
            this.fctb.CharHeight = 15;
            this.fctb.CharWidth = 7;
            this.fctb.ContextMenuStrip = this.contextMenuStrip1;
            this.fctb.CurrentLineColor = System.Drawing.Color.Gray;
            this.fctb.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fctb.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.fctb.Font = new System.Drawing.Font("Consolas", 9.75F);
            this.fctb.IsReplaceMode = false;
            this.fctb.Language = FastColoredTextBoxNS.Language.CSharp;
            this.fctb.LeftBracket = '(';
            this.fctb.LeftBracket2 = '{';
            this.fctb.LeftPadding = 15;
            this.fctb.Location = new System.Drawing.Point(0, 0);
            this.fctb.Name = "fctb";
            this.fctb.Paddings = new System.Windows.Forms.Padding(0);
            this.fctb.RightBracket = ')';
            this.fctb.RightBracket2 = '}';
            this.fctb.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(205)))));
            this.fctb.ShowFoldingLines = true;
            this.fctb.Size = new System.Drawing.Size(627, 327);
            this.fctb.TabIndex = 0;
            this.fctb.Zoom = 100;
            this.fctb.TextChanged += new System.EventHandler<FastColoredTextBoxNS.TextChangedEventArgs>(this.fctb_TextChanged);
            this.fctb.SelectionChanged += new System.EventHandler(this.fctb_SelectionChanged);
            this.fctb.SelectionChangedDelayed += new System.EventHandler(this.fctb_SelectionChangedDelayed);
            this.fctb.BackColorChanged += new System.EventHandler(this.fctb_BackColorChanged);
            this.fctb.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.fctb_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.recortarToolStripMenuItem,
            this.copiarToolStripMenuItem,
            this.colarToolStripMenuItem,
            this.selecionarTudoToolStripMenuItem,
            this.toolStripSeparator7,
            this.desfazerToolStripMenuItem,
            this.refazerToolStripMenuItem,
            this.toolStripSeparator8,
            this.procurarToolStripMenuItem1,
            this.substituirToolStripMenuItem1,
            this.toolStripSeparator9,
            this.clonarLinhaToolStripMenuItem,
            this.clonarComComentarioToolStripMenuItem,
            this.toolStripSeparator13,
            this.destacarToolStripMenuItem,
            this.removerDestaqueToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(203, 292);
            // 
            // recortarToolStripMenuItem
            // 
            this.recortarToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.cutpng;
            this.recortarToolStripMenuItem.Name = "recortarToolStripMenuItem";
            this.recortarToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.recortarToolStripMenuItem.Text = "Recortar";
            this.recortarToolStripMenuItem.Click += new System.EventHandler(this.recortarToolStripMenuItem1_Click);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.copypng;
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.copiarToolStripMenuItem.Text = "Copiar";
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.copiarToolStripMenuItem1_Click);
            // 
            // colarToolStripMenuItem
            // 
            this.colarToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.pastepng;
            this.colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            this.colarToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.colarToolStripMenuItem.Text = "Colar";
            this.colarToolStripMenuItem.Click += new System.EventHandler(this.colarToolStripMenuItem1_Click);
            // 
            // selecionarTudoToolStripMenuItem
            // 
            this.selecionarTudoToolStripMenuItem.Name = "selecionarTudoToolStripMenuItem";
            this.selecionarTudoToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.selecionarTudoToolStripMenuItem.Text = "Selecionar Tudo";
            this.selecionarTudoToolStripMenuItem.Click += new System.EventHandler(this.selecionarTudoToolStripMenuItem1_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(199, 6);
            // 
            // desfazerToolStripMenuItem
            // 
            this.desfazerToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.backarrow;
            this.desfazerToolStripMenuItem.Name = "desfazerToolStripMenuItem";
            this.desfazerToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.desfazerToolStripMenuItem.Text = "Desfazer";
            this.desfazerToolStripMenuItem.Click += new System.EventHandler(this.desfazerToolStripMenuItem1_Click);
            // 
            // refazerToolStripMenuItem
            // 
            this.refazerToolStripMenuItem.Image = global::CompiladorEasyCaio.Properties.Resources.nextarrow;
            this.refazerToolStripMenuItem.Name = "refazerToolStripMenuItem";
            this.refazerToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.refazerToolStripMenuItem.Text = "Refazer";
            this.refazerToolStripMenuItem.Click += new System.EventHandler(this.refazerToolStripMenuItem1_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(199, 6);
            // 
            // procurarToolStripMenuItem1
            // 
            this.procurarToolStripMenuItem1.Image = global::CompiladorEasyCaio.Properties.Resources.search;
            this.procurarToolStripMenuItem1.Name = "procurarToolStripMenuItem1";
            this.procurarToolStripMenuItem1.Size = new System.Drawing.Size(202, 22);
            this.procurarToolStripMenuItem1.Text = "Procurar";
            this.procurarToolStripMenuItem1.Click += new System.EventHandler(this.procurarToolStripMenuItem_Click);
            // 
            // substituirToolStripMenuItem1
            // 
            this.substituirToolStripMenuItem1.Name = "substituirToolStripMenuItem1";
            this.substituirToolStripMenuItem1.Size = new System.Drawing.Size(202, 22);
            this.substituirToolStripMenuItem1.Text = "Substituir";
            this.substituirToolStripMenuItem1.Click += new System.EventHandler(this.substituirToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(199, 6);
            // 
            // clonarLinhaToolStripMenuItem
            // 
            this.clonarLinhaToolStripMenuItem.Name = "clonarLinhaToolStripMenuItem";
            this.clonarLinhaToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.clonarLinhaToolStripMenuItem.Text = "Clonar Linha(s)";
            this.clonarLinhaToolStripMenuItem.Click += new System.EventHandler(this.clonarLinhaToolStripMenuItem_Click);
            // 
            // clonarComComentarioToolStripMenuItem
            // 
            this.clonarComComentarioToolStripMenuItem.Name = "clonarComComentarioToolStripMenuItem";
            this.clonarComComentarioToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.clonarComComentarioToolStripMenuItem.Text = "Clonar com Comentário";
            this.clonarComComentarioToolStripMenuItem.Click += new System.EventHandler(this.clonarComComentarioToolStripMenuItem_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(199, 6);
            // 
            // destacarToolStripMenuItem
            // 
            this.destacarToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.destacarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.azulToolStripMenuItem,
            this.vermelhoToolStripMenuItem,
            this.amareloToolStripMenuItem,
            this.verdeToolStripMenuItem,
            this.toolStripSeparator14});
            this.destacarToolStripMenuItem.ForeColor = System.Drawing.Color.Red;
            this.destacarToolStripMenuItem.Name = "destacarToolStripMenuItem";
            this.destacarToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.destacarToolStripMenuItem.Text = "Destacar";
            this.destacarToolStripMenuItem.Click += new System.EventHandler(this.destacarToolStripMenuItem_Click);
            // 
            // azulToolStripMenuItem
            // 
            this.azulToolStripMenuItem.Name = "azulToolStripMenuItem";
            this.azulToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.azulToolStripMenuItem.Tag = "Blue";
            this.azulToolStripMenuItem.Text = "Azul";
            this.azulToolStripMenuItem.Click += new System.EventHandler(this.subCoresDestacarToolStripMenuItem_Click);
            // 
            // vermelhoToolStripMenuItem
            // 
            this.vermelhoToolStripMenuItem.Name = "vermelhoToolStripMenuItem";
            this.vermelhoToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.vermelhoToolStripMenuItem.Tag = "Red";
            this.vermelhoToolStripMenuItem.Text = "Vermelho";
            this.vermelhoToolStripMenuItem.Click += new System.EventHandler(this.subCoresDestacarToolStripMenuItem_Click);
            // 
            // amareloToolStripMenuItem
            // 
            this.amareloToolStripMenuItem.Name = "amareloToolStripMenuItem";
            this.amareloToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.amareloToolStripMenuItem.Tag = "Yellow";
            this.amareloToolStripMenuItem.Text = "Amarelo";
            this.amareloToolStripMenuItem.Click += new System.EventHandler(this.subCoresDestacarToolStripMenuItem_Click);
            // 
            // verdeToolStripMenuItem
            // 
            this.verdeToolStripMenuItem.Name = "verdeToolStripMenuItem";
            this.verdeToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.verdeToolStripMenuItem.Tag = "Green";
            this.verdeToolStripMenuItem.Text = "Verde";
            this.verdeToolStripMenuItem.Click += new System.EventHandler(this.subCoresDestacarToolStripMenuItem_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(121, 6);
            // 
            // removerDestaqueToolStripMenuItem
            // 
            this.removerDestaqueToolStripMenuItem.Name = "removerDestaqueToolStripMenuItem";
            this.removerDestaqueToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.removerDestaqueToolStripMenuItem.Text = "Remover Destaque";
            this.removerDestaqueToolStripMenuItem.Click += new System.EventHandler(this.removerDestaqueToolStripMenuItem_Click);
            // 
            // linkPastaArquivos
            // 
            this.linkPastaArquivos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.linkPastaArquivos.AutoSize = true;
            this.linkPastaArquivos.BackColor = System.Drawing.SystemColors.Window;
            this.linkPastaArquivos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkPastaArquivos.Location = new System.Drawing.Point(554, 39);
            this.linkPastaArquivos.Name = "linkPastaArquivos";
            this.linkPastaArquivos.Size = new System.Drawing.Size(66, 15);
            this.linkPastaArquivos.TabIndex = 1;
            this.linkPastaArquivos.TabStop = true;
            this.linkPastaArquivos.Text = "Abrir Pasta";
            this.linkPastaArquivos.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkPastaArquivos_LinkClicked);
            // 
            // txtStatus
            // 
            this.txtStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.Location = new System.Drawing.Point(0, 0);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(627, 61);
            this.txtStatus.TabIndex = 0;
            this.txtStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 468);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(300, 250);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fctb)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuracoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comandosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox txtOutput;
        private System.Windows.Forms.ToolStripButton btnPastaSaidaExe;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnCompilar;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private FastColoredTextBoxNS.FastColoredTextBox fctb;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem novoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem imprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton chkDestacarLinhaAtual;
        private System.Windows.Forms.ToolStripButton chkExibirDobrasDeLinhas;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton btnComentar;
        private System.Windows.Forms.ToolStripButton btnAutoIdentar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton btnAddBookMarks;
        private System.Windows.Forms.ToolStripButton btnRemoverBookMarks;
        private System.Windows.Forms.ToolStripButton chkAutoFecharChaves;
        private System.Windows.Forms.ToolStripButton btnBookBack;
        private System.Windows.Forms.ToolStripButton btnBookNext;
        private System.Windows.Forms.ToolStripMenuItem procurarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem substituirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teclasDeAtalhosToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton btnDescomentar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripStatusLabel lblQtdCaracteres;
        private System.Windows.Forms.ToolStripStatusLabel lblLinhaAtual;
        private System.Windows.Forms.ToolStripStatusLabel lblColunaAtual;
        private System.Windows.Forms.ToolStripMenuItem salvarComoToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem recortarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selecionarTudoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem desfazerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refazerToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem procurarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem substituirToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem clonarLinhaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clonarComComentarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desfazerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem refazerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem recortarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem colarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem selecionarTudoToolStripMenuItem1;
        private System.Windows.Forms.LinkLabel linkPastaArquivos;
        private System.Windows.Forms.ToolStripComboBox cboTemas;
        private System.Windows.Forms.ToolStripMenuItem chkQuebraDeLinhas;
        private System.Windows.Forms.ToolStripMenuItem chkScrollMap;
        private FastColoredTextBoxNS.DocumentMap documentMap1;
        private System.Windows.Forms.ToolStripMenuItem esconderErroListToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem corDeFundoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fonteToolStripMenuItem;
        private System.Windows.Forms.ToolStripLabel lblFramworkInfo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripMenuItem destacarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem azulToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vermelhoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem amareloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verdeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removerDestaqueToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
    }
}

