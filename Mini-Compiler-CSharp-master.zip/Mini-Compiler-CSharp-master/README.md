Mini Compilador C# 
============================

Projeto criado no Visual Studio Express 2012 for Desktop em Window Forms para fins didáticos.

Leve e simples, Feito para poder praticar a programação no modo Console Application no framework 4.0 sem a necessidade de instalar a IDE, é necessário ter .net framework 4.0.

tamanho: 500kb
baixar executavel: https://sourceforge.net/projects/mini-compilador-c-compil/

--------------------------------
### Interface
![](/images/demo1.png)

### Color Theme
![](/images/demo2.png)  

### Compilando
![](/images/demo3.png) 
![](/images/demo4.png) 
![](/images/demo5.png) 
